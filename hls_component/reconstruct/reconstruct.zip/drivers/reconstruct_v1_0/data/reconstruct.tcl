# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
# Tool Version Limit: 2024.11
# Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
# Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
# 
# ==============================================================
proc generate {drv_handle} {
    xdefine_include_file $drv_handle "xparameters.h" "XReconstruct" \
        "NUM_INSTANCES" \
        "DEVICE_ID" \
        "C_S_AXI_CONTROL_BASEADDR" \
        "C_S_AXI_CONTROL_HIGHADDR" \
        "C_S_AXI_SCALAR_DATA_BASEADDR" \
        "C_S_AXI_SCALAR_DATA_HIGHADDR"

    xdefine_config_file $drv_handle "xreconstruct_g.c" "XReconstruct" \
        "DEVICE_ID" \
        "C_S_AXI_CONTROL_BASEADDR" \
        "C_S_AXI_SCALAR_DATA_BASEADDR"

    xdefine_canonical_xpars $drv_handle "xparameters.h" "XReconstruct" \
        "DEVICE_ID" \
        "C_S_AXI_CONTROL_BASEADDR" \
        "C_S_AXI_CONTROL_HIGHADDR" \
        "C_S_AXI_SCALAR_DATA_BASEADDR" \
        "C_S_AXI_SCALAR_DATA_HIGHADDR"
}

