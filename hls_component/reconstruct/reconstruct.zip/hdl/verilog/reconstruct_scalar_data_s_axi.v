// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module reconstruct_scalar_data_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 7,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [31:0]                   atomLocationsSize,
    output wire [31:0]                   projShape0,
    output wire [31:0]                   projShape1,
    output wire [31:0]                   psfSupersample,
    output wire [31:0]                   imageProjectionSize,
    output wire [31:0]                   fullImage_rows,
    output wire [31:0]                   fullImage_cols
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_none
//
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of atomLocationsSize
//        bit 31~0 - atomLocationsSize[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of projShape0
//        bit 31~0 - projShape0[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of projShape1
//        bit 31~0 - projShape1[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of psfSupersample
//        bit 31~0 - psfSupersample[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of imageProjectionSize
//        bit 31~0 - imageProjectionSize[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of fullImage_rows
//        bit 31~0 - fullImage_rows[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of fullImage_cols
//        bit 31~0 - fullImage_cols[31:0] (Read/Write)
// 0x44 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_ATOMLOCATIONSSIZE_DATA_0   = 7'h10,
    ADDR_ATOMLOCATIONSSIZE_CTRL     = 7'h14,
    ADDR_PROJSHAPE0_DATA_0          = 7'h18,
    ADDR_PROJSHAPE0_CTRL            = 7'h1c,
    ADDR_PROJSHAPE1_DATA_0          = 7'h20,
    ADDR_PROJSHAPE1_CTRL            = 7'h24,
    ADDR_PSFSUPERSAMPLE_DATA_0      = 7'h28,
    ADDR_PSFSUPERSAMPLE_CTRL        = 7'h2c,
    ADDR_IMAGEPROJECTIONSIZE_DATA_0 = 7'h30,
    ADDR_IMAGEPROJECTIONSIZE_CTRL   = 7'h34,
    ADDR_FULLIMAGE_ROWS_DATA_0      = 7'h38,
    ADDR_FULLIMAGE_ROWS_CTRL        = 7'h3c,
    ADDR_FULLIMAGE_COLS_DATA_0      = 7'h40,
    ADDR_FULLIMAGE_COLS_CTRL        = 7'h44,
    WRIDLE                          = 2'd0,
    WRDATA                          = 2'd1,
    WRRESP                          = 2'd2,
    WRRESET                         = 2'd3,
    RDIDLE                          = 2'd0,
    RDDATA                          = 2'd1,
    RDRESET                         = 2'd2,
    ADDR_BITS                = 7;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [31:0]                   int_atomLocationsSize = 'b0;
    reg  [31:0]                   int_projShape0 = 'b0;
    reg  [31:0]                   int_projShape1 = 'b0;
    reg  [31:0]                   int_psfSupersample = 'b0;
    reg  [31:0]                   int_imageProjectionSize = 'b0;
    reg  [31:0]                   int_fullImage_rows = 'b0;
    reg  [31:0]                   int_fullImage_cols = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_ATOMLOCATIONSSIZE_DATA_0: begin
                    rdata <= int_atomLocationsSize[31:0];
                end
                ADDR_PROJSHAPE0_DATA_0: begin
                    rdata <= int_projShape0[31:0];
                end
                ADDR_PROJSHAPE1_DATA_0: begin
                    rdata <= int_projShape1[31:0];
                end
                ADDR_PSFSUPERSAMPLE_DATA_0: begin
                    rdata <= int_psfSupersample[31:0];
                end
                ADDR_IMAGEPROJECTIONSIZE_DATA_0: begin
                    rdata <= int_imageProjectionSize[31:0];
                end
                ADDR_FULLIMAGE_ROWS_DATA_0: begin
                    rdata <= int_fullImage_rows[31:0];
                end
                ADDR_FULLIMAGE_COLS_DATA_0: begin
                    rdata <= int_fullImage_cols[31:0];
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign atomLocationsSize   = int_atomLocationsSize;
assign projShape0          = int_projShape0;
assign projShape1          = int_projShape1;
assign psfSupersample      = int_psfSupersample;
assign imageProjectionSize = int_imageProjectionSize;
assign fullImage_rows      = int_fullImage_rows;
assign fullImage_cols      = int_fullImage_cols;
// int_atomLocationsSize[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_atomLocationsSize[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ATOMLOCATIONSSIZE_DATA_0)
            int_atomLocationsSize[31:0] <= (WDATA[31:0] & wmask) | (int_atomLocationsSize[31:0] & ~wmask);
    end
end

// int_projShape0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_projShape0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PROJSHAPE0_DATA_0)
            int_projShape0[31:0] <= (WDATA[31:0] & wmask) | (int_projShape0[31:0] & ~wmask);
    end
end

// int_projShape1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_projShape1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PROJSHAPE1_DATA_0)
            int_projShape1[31:0] <= (WDATA[31:0] & wmask) | (int_projShape1[31:0] & ~wmask);
    end
end

// int_psfSupersample[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_psfSupersample[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PSFSUPERSAMPLE_DATA_0)
            int_psfSupersample[31:0] <= (WDATA[31:0] & wmask) | (int_psfSupersample[31:0] & ~wmask);
    end
end

// int_imageProjectionSize[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_imageProjectionSize[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IMAGEPROJECTIONSIZE_DATA_0)
            int_imageProjectionSize[31:0] <= (WDATA[31:0] & wmask) | (int_imageProjectionSize[31:0] & ~wmask);
    end
end

// int_fullImage_rows[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_fullImage_rows[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_FULLIMAGE_ROWS_DATA_0)
            int_fullImage_rows[31:0] <= (WDATA[31:0] & wmask) | (int_fullImage_rows[31:0] & ~wmask);
    end
end

// int_fullImage_cols[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_fullImage_cols[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_FULLIMAGE_COLS_DATA_0)
            int_fullImage_cols[31:0] <= (WDATA[31:0] & wmask) | (int_fullImage_cols[31:0] & ~wmask);
    end
end


//------------------------Memory logic-------------------

endmodule
